/* microPAM_V3
 * Copyright (c) 2023/2024/2025/2026, Walter Zimmer
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice, development funding notice, and this permission
 * notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
// User-facing recording settings. Everything hardware-dependent is derived in src/global.h.
// Values set here are defaults; /config.txt on the SD card overrides them at boot.
#ifndef CONFIG_H
#define CONFIG_H

  //------------------------------------
  // processing mode
  //------------------------------------
  #define PROC_MODE 1   // 0: raw WAV (.wav); 1: compressed raw (.bin)

  //------------------------------------
  // duty cycle
  //------------------------------------
  #define T_ACQ     60  // seconds per file
  #define T_ON      1   // minutes on per repetition period
  #define T_REP     0   // minutes per repetition period (continuous recording if T_REP <= T_ON)

  //------------------------------------
  // acquisition
  //------------------------------------
  #define FSAMP 192000  // Hz; capped at 192 kHz on RP2040 and 384 kHz on RP2350 (192 kHz with NCHAN 4)
  #define NCHAN     0   // 0: board default (1 channel on RP2040, 2 on RP2350); 4: all four ADC inputs

  //------------------------------------
  // file metadata (WAV LIST/INFO chunk)
  //------------------------------------
  // 'Source' as <name>-<C0>: C0 is the level in dB re 1 uPa of one 24-bit ADC count at
  // 0 dB analog gain (Python/micropam_calib.py). LC17 = SQ17-00 on the LC-Mare front end,
  // from the resistor measurement of unit 1B843C2E (42.8 dB at 20 dB gain and SHIFT 12)
  #define SRC_str "LC17-38.7"
  #define CMS_str "WMXZ"     // 'Commissioned' (organization)
  #define ART_str "WMXZ"     // 'Artist'  (creator)
  #define PRD_str "microPAM" // 'Product' (project)
  #define SBJ_str "______"   // 'Subject' (area)
  #define NAM_str "Test"     // 'Name'    (location id)

#endif
