/* microPAM_V3
 * Copyright (c) 2023/2024/2025/2026, Walter Zimmer
 * MIT license; see config.h for the full notice.
 */
// Hardware-dependent definitions derived from config.h.
#ifndef GLOBAL_H
#define GLOBAL_H

#include <stdint.h>
#include "../config.h"

  #define Program "microPAM_V3"
  #define Version "3.4.2" // 05-11-2026 (recording hours: end hours excluded)

  // hardware (descriptive only)
  //   ADC:  TLV320ADC6140 (ADC_V2 board), TDM, 32 bit
  //   RTC:  RV-3028 (Pimoroni breakout)
  //   base: LC_MARE_09_2025

  #define PREAMP    0     // 0: CMOS; 1: FET; 2: Mark (selects analog gain and ADC channel)

  #define WAIT      5     // seconds to wait for USB serial at boot (0: do not wait)

  //------------------------------------
  // MCU dispatch
  //------------------------------------
  #define RP_2040 1
  #define RP_2350 2
  #if defined(ARDUINO_ADAFRUIT_FEATHER_RP2040_ADALOGGER)
    #define MCU RP_2040
    #define MCU_NAME "RP2040"
  #elif defined(ARDUINO_ADAFRUIT_FEATHER_RP2350_HSTX)
    #define MCU RP_2350
    #define MCU_NAME "RP2350"
  #else
    #error "unsupported board: use Adafruit Feather RP2040 Adalogger or Feather RP2350 HSTX"
  #endif

  #if (PROC_MODE != 0) && (PROC_MODE != 1)
    #error "PROC_MODE must be 0 (raw) or 1 (compressed)"
  #endif

  //------------------------------------
  // acquisition
  //------------------------------------
  #if MCU==RP_2040
    #define SD_CS       23
    #define XRTC_INT_PIN 15
  #elif MCU==RP_2350
    #define SD_CS       25
    #define XRTC_INT_PIN 29
  #endif

  // NCH: channels (TDM slots and WAV header)
  #if NCHAN==0 && MCU==RP_2040
    #define NCH         1
    #define FSAMP_MAX   192000
  #elif NCHAN==0
    #define NCH         2
    #define FSAMP_MAX   384000
  #elif NCHAN==4
    #define NCH         4
    #define FSAMP_MAX   192000  // bit clock 4*32*192 kHz = 24.576 MHz, as 2 channels at 384 kHz
  #else
    #error "NCHAN must be 0 (board default) or 4"
  #endif
  #if FSAMP>FSAMP_MAX
    #undef  FSAMP
    #define FSAMP FSAMP_MAX
  #endif

  #define MBIT      32      // bits per TDM slot

  #define NBUF_ACQ  1024    // words per DMA buffer (one acquisition chunk)
  #define MD        8       // acquisition chunks per queue block (disk write unit)
  #define NBLOCK    (MD*NBUF_ACQ)

  #if defined(RP2350_PSRAM_CS)
    #define MAX_QUEUE (225) // 225*8*1024*4 B = 7.2 MB (8 MB PSRAM)
  #else
    #define MAX_QUEUE (5)   //   5*8*1024*4 B = 160 kB
  #endif

  // file format (identical to microPAM_V5)
  #define COMP_MAGIC 0x434F4D50u  // "COMP": compressed record sync word
  #define NAVG       1            // no averaging (V5 IKEY field)

  // right shift applied before compression (drops the 8 zero-padding bits and 4 noise bits)
  #if PROC_MODE==0
    #define SHIFT (0)
  #else
    #define SHIFT (8+4)
  #endif

  // ADC gain
  #if PREAMP==0
    #define AGAIN 20        // dB
  #else
    #define AGAIN 0
  #endif
  #define DGAIN 0

  // MCU clock follows the sampling frequency (multiples of 12 MHz)
  #if NCH==4        // same word rates as 2 channels at twice the sampling frequency
    #if FSAMP<=96000
      #define CLK_MULT 8    // 96 MHz
    #else
      #define CLK_MULT 12   // 144 MHz
    #endif
  #elif FSAMP<=96000
    #define CLK_MULT 4      // 48 MHz
  #elif FSAMP<=192000
    #define CLK_MULT 8      // 96 MHz
  #else
    #define CLK_MULT 12     // 144 MHz
  #endif

  #define SD_MULT   6       // SPI clock 72 MHz (a little high, but works)

  //------------------------------------
  // program states
  //------------------------------------
  enum status_t {DO_START, CLOSED, RECORDING, MUST_STOP, JUST_STOPPED, STOPPED};
  extern const char status_text[][16];

  //------------------------------------
  // run-time parameters
  //------------------------------------
  // filing.cxx
  extern uint16_t t_acq;   // seconds (each file)
  extern uint16_t t_on;    // minutes (each on period)
  extern uint16_t t_rep;   // minutes (continuous recording if t_rep <= t_on)
  extern uint16_t h_rec[]; // hours for selective recordings {0,12,12,24}

  extern char ISRC[];
  extern char ICMS[];
  extern char IART[];
  extern char IPRD[];
  extern char ISBJ[];
  extern char INAM[];
  extern char startTime[]; // yyyy-mm-dd_hh:mm:ss

  // rp2x.cxx
  extern uint32_t fsamp;   // Hz

  // adc.cxx
  extern uint32_t again;   // dB

  // .ino
  extern uint32_t loop_count;
  extern uint32_t data_count;

#endif
